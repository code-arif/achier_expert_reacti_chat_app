<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('default/datatable.css')); ?>" rel="stylesheet" />  
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!--app-content open-->
<div class="app-content main-content mt-0">
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">Edit Social Media</h1>
                </div>
                <div class="ms-auto pageheader-btn">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Social Media</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </div>
            </div>
            <!-- PAGE-HEADER END -->

            <!-- ROW-4 -->
            <div class="row">
                <div class="col-12 col-sm-12">
                    <div class="card product-sales-main">
                        <div class="card-header border-bottom">
                            <h3 class="card-title mb-0">Edit Social Media</h3>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.social_media.update', $socialMedia->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group">
                                    <label for="profile_link">Profile Link</label>
                                    <input type="url" class="form-control" id="profile_link" name="profile_link" value="<?php echo e($socialMedia->profile_link); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="social_media_icon">Social Media Icon</label>
                                    <input type="file" class="form-control" id="social_media_icon" name="social_media_icon">
                                    <?php if($socialMedia->social_media_icon): ?>
                                        <img src="<?php echo e(asset($socialMedia->social_media_icon)); ?>" alt="icon" width="50px" height="50px" style="margin-top: 10px;">
                                    <?php endif; ?>
                                </div>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </form>
                        </div>
                    </div>
                </div><!-- COL END -->
            </div>
            <!-- ROW-4 END -->

        </div>
    </div>
</div>
<!-- CONTAINER CLOSED -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.app', ['title' => 'Edit Social Media'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rufuz\Herd\fsd_all_project\achiar_expert_backend\resources\views\backend\layouts\socialmedia\edit.blade.php ENDPATH**/ ?>