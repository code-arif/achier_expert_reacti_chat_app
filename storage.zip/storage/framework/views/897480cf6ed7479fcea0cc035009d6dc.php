<?php $__env->startSection('content'); ?>
<!-- CONTAINER OPEN -->
<div class="col col-login mx-auto text-center">
    
</div>
<div class="container-login100">
    <div class="wrap-login100 p-5 bg-white rounded-lg shadow" style="max-width: 400px;">
        <div class="card-body text-center">
            <h4 class="mb-4 font-weight-bold">Welcome Back!</h4>
            <p class="text-muted mb-4">Log in to access your dashboard</p>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-lg btn-block">
                Login
            </a>
        </div>
    </div>
</div>
<!-- CONTAINER CLOSED -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('auth.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rufuz\Herd\fsd_all_project\achiar_expert_backend\resources\views\welcome.blade.php ENDPATH**/ ?>