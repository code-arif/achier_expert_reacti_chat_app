<!-- GLOBAL-LOADER -->
<div id="global-loader">
    <img src="<?php echo e(asset('default/loader.gif')); ?>" class="loader-img" alt="Loader" style="width: 100px;">
</div>
<!-- /GLOBAL-LOADER -->
<?php /**PATH C:\Users\rufuz\Herd\fsd_all_project\achiar_expert_backend\resources\views\backend\partials\loader.blade.php ENDPATH**/ ?>