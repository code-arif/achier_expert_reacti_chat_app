<?php $__env->startSection('content'); ?>
<!--app-content open-->
<div class="app-content main-content mt-0">
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">Business Profile Details</h1>
                </div>
                <div class="ms-auto pageheader-btn">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Business Profiles</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Details</li>
                    </ol>
                </div>
            </div>
            <!-- PAGE-HEADER END -->

            <!-- ROW-4 -->
            <div class="row">
                <div class="col-12 col-sm-12">
                    <div class="card product-sales-main">
                        <div class="card-header border-bottom">
                            <h3 class="card-title mb-0"><?php echo e($profile->venue_name); ?></h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>User:</strong> <?php echo e($profile->user->f_name); ?> <?php echo e($profile->user->l_name); ?></p>
                                    <p><strong>Email:</strong> <?php echo e($profile->user->email); ?></p>
                                    <p><strong>Establishment:</strong> <?php echo e($profile->establishment->name); ?></p>
                                    <p><strong>Status:</strong> <?php echo e($profile->status); ?></p>
                                    <p><strong>Open Hour:</strong> <?php echo e($profile->open_hour); ?></p>
                                    <p><strong>Close Hour:</strong> <?php echo e($profile->close_hour); ?></p>
                                    <p><strong>Menu:</strong> <?php echo e($profile->menu); ?></p>
                                    <p><strong>Is Premium:</strong> <?php echo e($profile->is_premium ? 'Yes' : 'No'); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <img src="<?php echo e($profile->cover); ?>" alt="Cover Image" class="img-fluid">
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- COL END -->
            </div>
            <!-- ROW-4 END -->

        </div>
    </div>
</div>
<!-- CONTAINER CLOSED -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', ['title' => 'Business Profile Details'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rufuz\Herd\fsd_all_project\achiar_expert_backend\resources\views\backend\layouts\business_profile\view.blade.php ENDPATH**/ ?>