<script>
    function newUserCount() {
        $.ajax({
            url: "",
            method: "GET",
            dataType: "JSON",
            success: function(response) {
                $('#newUserCount').html(response.data);
                $('#userCount').html(response.data);
            }
        });
    };
    newUserCount();
</script>
<?php /**PATH C:\Users\rufuz\Herd\fsd_all_project\achiar_expert_backend\resources\views\backend\partials\ajax.blade.php ENDPATH**/ ?>