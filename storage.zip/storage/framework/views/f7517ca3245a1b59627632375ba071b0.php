<?php
$settings = \App\Models\Setting::first();
?>
<!doctype html>
<html lang="en" dir="ltr">
<head>
    <!-- META DATA -->
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="<?php echo strip_tags($settings->description ?? ''); ?>">
    <meta name="author" content="<?php echo e($settings->author ?? ''); ?>">
    <meta name="keywords" content="<?php echo strip_tags($settings->keywords ?? ''); ?>">

    <!-- FAVICON -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset($settings->favicon ?? 'default/logo.png')); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css">

    <!-- TITLE -->
    <title> <?php echo $__env->yieldContent('title'); ?> </title>
    <!-- Scripts -->

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>



    <?php echo $__env->make('backend.partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


</head>

<body class="ltr app sidebar-mini">
    <?php echo $__env->make('backend.partials.switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('backend.partials.loader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- PAGE -->
    <div class="page">
        <div class="page-main">
            <?php echo $__env->make('backend.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('backend.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->make('backend.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>
    <!-- page -->
    <?php echo $__env->make('backend.partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\rufuz\Herd\fsd_all_project\achiar_expert_backend\resources\views\backend\app.blade.php ENDPATH**/ ?>