<!-- BACK-TO-TOP -->
<a href="#top" id="back-to-top"><i class="fa fa-long-arrow-up"></i></a>


<!-- JQUERY JS -->
<script src="<?php echo e(asset('backend/plugins/jquery/jquery.min.js')); ?>"></script>




<!-- BOOTSTRAP JS -->
<script src="<?php echo e(asset('backend/plugins/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- SIDE-MENU JS -->
<script src="<?php echo e(asset('backend/plugins/sidemenu/sidemenu.js')); ?>"></script>

<!-- Perfect SCROLLBAR JS-->
<script src="<?php echo e(asset('backend/plugins/p-scroll/perfect-scrollbar.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('backend/plugins/p-scroll/pscroll.js')); ?>"></script> -->

<!-- STICKY JS -->
<script src="<?php echo e(asset('backend/js/sticky.js')); ?>"></script>


<!-- APEXCHART JS -->
<script src="<?php echo e(asset('backend/js/apexcharts.js')); ?>"></script>

<!-- INTERNAL SELECT2 JS -->
<script src="<?php echo e(asset('backend/plugins/select2/select2.full.min.js')); ?>"></script>

<!-- CHART-CIRCLE JS-->
<script src="<?php echo e(asset('backend/plugins/circle-progress/circle-progress.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/datatable/js/dataTables.bootstrap5.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/datatable/js/dataTables.buttons.min.js')); ?>"></script>

<script src="<?php echo e(asset('backend/plugins/datatable/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/datatable/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/datatable/pdfmake/vfs_fonts.js')); ?>"></script>

<script src="<?php echo e(asset('backend/plugins/datatable/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/datatable/js/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/datatable/responsive.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/table-data.js')); ?>"></script>

<!-- INDEX JS -->
<script src="<?php echo e(asset('backend/js/index1.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/index.js')); ?>"></script>

<!-- Reply JS-->
<script src="<?php echo e(asset('backend/js/reply.js')); ?>"></script>


<!-- COLOR THEME JS -->
<script src="<?php echo e(asset('backend/js/themeColors.js')); ?>"></script>

<!-- CUSTOM JS -->
<script src="<?php echo e(asset('backend/js/custom.js')); ?>"></script>

<!-- SWITCHER JS -->
<script src="<?php echo e(asset('backend/switcher/js/switcher.js')); ?>"></script>

<!-- INTERNAL Summernote Editor js -->
<script src="<?php echo e(asset('backend/plugins/summernote-editor/summernote1.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/summernote.js')); ?>"></script>


<script src="<?php echo e(asset('backend/js/toastr.min.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.js"></script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js" integrity="sha512-8QFTrG0oeOiyWo/VM9Y8kgxdlCryqhIxVeRpWSezdRRAvarxVtwLnGroJgnVW9/XBRduxO/z1GblzPrMQoeuew==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $('.dropify').dropify();
</script>



<script src="https://cdn.ckeditor.com/ckeditor5/41.2.0/classic/ckeditor.js"></script>
<script>
    var elements = document.querySelectorAll('.description');

    for (var i = 0; i < elements.length; i++) {
        ClassicEditor
            .create(elements[i], {
                height: '500px'
            })
            .catch(error => {
                console.error(error);
            });
    }
</script>


<!-- loader -->
<script src="<?php echo e(asset('default')); ?>/nprogress/nprogress.js"></script>


<!-- Toster -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<script>
    toastr.options = {
        "closeButton": true,
        "positionClass": "toast-top-right",
        "timeOut": "5000"
    };
</script>

<?php echo $__env->make('backend.partials.toster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('backend.partials.ajax', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('backend.partials.notification', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH C:\Users\rufuz\Herd\fsd_all_project\achiar_expert_backend\resources\views\backend\partials\scripts.blade.php ENDPATH**/ ?>