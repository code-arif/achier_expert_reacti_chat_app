<script>
    <?php if(session()->has('t-success')): ?>
        toastr.success("<?php echo e(session('t-success')); ?>");
        <?php echo e(session()->forget('t-success')); ?>

    <?php endif; ?>
    <?php if(session()->has('t-error')): ?>
        toastr.error("<?php echo e(session('t-error')); ?>");
        <?php echo e(session()->forget('t-error')); ?>

    <?php endif; ?>
</script>
<?php /**PATH C:\Users\rufuz\Herd\fsd_all_project\achiar_expert_backend\resources\views\backend\partials\toster.blade.php ENDPATH**/ ?>